package com.cidades.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cidades.models.Users;

public interface UsersRepository extends JpaRepository<Users, String>{

	Users findByNome(String nome);
}
