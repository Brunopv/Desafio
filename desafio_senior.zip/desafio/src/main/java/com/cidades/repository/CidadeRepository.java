package com.cidades.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cidades.models.Cidade;


public interface CidadeRepository extends JpaRepository<Cidade, String>{

	Cidade findByCodigo(long codigo);
	
	
	@Query(value = "SELECT * FROM CIDADE WHERE CAPITAL IS NOT NULL ORDER BY NAME", nativeQuery = true)
    public List<Cidade> findCapital();
}
