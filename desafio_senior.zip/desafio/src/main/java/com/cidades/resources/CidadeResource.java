package com.cidades.resources;

import java.util.ArrayList;

import javax.validation.Valid;
import javax.websocket.server.PathParam;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cidades.models.Cidade;
import com.cidades.repository.CidadeRepository;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Api(value="API REST Cidades")
@RestController
@RequestMapping("/cidade")
public class CidadeResource {

	@Autowired
	private CidadeRepository er;
	
	@ApiOperation(value="Retorna uma lista de Cidades")
	@GetMapping(produces="application/json")
	public @ResponseBody  ArrayList<Cidade> listaCidades(){
		Iterable<Cidade> listaCidades = er.findAll();
		ArrayList<Cidade> cidades = new ArrayList<Cidade>();
		for(Cidade cidade : listaCidades){
			long codigo = cidade.getCodigo();
			cidade.add(linkTo(methodOn(CidadeResource.class).cidade(codigo)).withSelfRel());
			cidades.add(cidade);
		}
		return cidades;
	}
	
	@ApiOperation(value="Retorna uma cidade específica")
	@GetMapping(value="/{codigo}", produces="application/json")
	public @ResponseBody Cidade cidade(@PathVariable(value="codigo") long codigo){
		Cidade cidade = er.findByCodigo(codigo);
		cidade.add(linkTo(methodOn(CidadeResource.class).listaCidades()).withRel("Lista de Cidades"));
		return cidade;
	}
	
	@ApiOperation(value="Salva cidade")
	@PostMapping()
	public Cidade cadastraCidade(@RequestBody @Valid Cidade cidade){
		er.save(cidade);
		long codigo = cidade.getCodigo();
		cidade.add(linkTo(methodOn(CidadeResource.class).cidade(codigo)).withSelfRel());
		return cidade;
	}
	
	@ApiOperation(value="Deleta cidade")
	@DeleteMapping()
	public Cidade deletaCidade(@RequestBody Cidade cidade){
		er.delete(cidade);
		return cidade;
	}

}
